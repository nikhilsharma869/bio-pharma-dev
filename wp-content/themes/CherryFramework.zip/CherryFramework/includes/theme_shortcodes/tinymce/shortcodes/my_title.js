frameworkShortcodeAtts={
    attributes:[
            {
                label:"Title Text",
                id:"title",
                help:"Enter text for title."
            },
            {
                label:"Subtitle Text",
                id:"subtitle",
                help:"Enter text for subtitle."
            },
            {
                label:"Title Icon",
                id:"icon",
                help:"Enter path to the icon image."
            }
    ],
    defaultContent:"",
    shortcode:"title_box",
    shortcodeType: "text-replace"
};